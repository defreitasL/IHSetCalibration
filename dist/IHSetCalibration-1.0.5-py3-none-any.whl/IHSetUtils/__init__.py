# src/__init__.py

# Import modules and functions from your package here
from .objectives_functions import multi_obj_func